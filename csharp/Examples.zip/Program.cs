﻿using System;

//중복되는 클래스이름을 피하기 위해
namespace Examples
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
    }
}
