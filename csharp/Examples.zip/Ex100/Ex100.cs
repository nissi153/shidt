﻿using System;

namespace Examples.Ex100
{
    internal class Ex100
    {
        static void Main(string[] args)
        {
            //ex01
            //Console.WriteLine("Hello");
            //ex02
            //Console.WriteLine("Hello World");
            //ex03
            //Console.WriteLine("Hello\nWorld");
            //ex04
            //'Hello' C#은 단따옴표와 쌍따옴표를 구분한다.
            //Console.WriteLine("'Hello'");
            //ex05
            //"Hello World"
            Console.WriteLine("\"Hello\"");
        }
    }
}
